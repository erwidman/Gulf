1. Login Screen
		Here you have two options, input your login information or create a new account.

2. Create an Account Screen
		Simply enter your desired login infomatino and click to create a new acocunt,
		The app will automatically log you in from here.
	
3. Main Screen
		Here are four different options.
		Statistics, and options are currently unfunctional.
		Close will bring you back to the login screen.
		Play Game will bring you to the golf course search screen.

4. Golf Course Selection Screen
		Theres a place to seach for your golf course, if not found, then you can 
		click a create unlisted course button to make a new course. Click on a listed course after typeing in the search bar and pressing the search button to move onto the scorecard.

5. Create Unlisted Course Sccreen
		This brings to two buttons to be clicked on. The top button will allow you to create
		the course as you play the game, this is currently not functional.

		The Enter Scorecard Before Round button will bring you to a screen where you can input the
		name of the course, the city an state the course is located in, and the number of holes
		in the course. Click enter to start entering the information hole by hole.
		When you click enter you are then prompted to enter the information for the lengths from
		all the tees and the par of the hole. After it will bring you back o the Golf Course Selection Screen.

6. Scorecard
		Use next and previous buttons to select your hole, the selected hole is the furthest to the left on your screen. To enter your score, type in your score in the "Score on Hole" text field and click the Enter Score Button. Once you are done, click the submit button.